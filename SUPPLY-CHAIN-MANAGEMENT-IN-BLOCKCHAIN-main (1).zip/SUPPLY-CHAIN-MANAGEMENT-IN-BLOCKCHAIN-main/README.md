# SUPPLY-CHAIN-MANAGEMENT-IN-BLOCKCHAIN
This is a project where the system tells about the supplying process of the raw materials

HOME PAGE
![1](https://user-images.githubusercontent.com/90173123/218174322-aa69a417-19b0-45f6-84c8-200849aabc29.PNG)
PRODUCT ORDERING PAGE
![2](https://user-images.githubusercontent.com/90173123/218174460-ca6ba161-1af6-43e4-9160-82b7167556ff.PNG)
SUPPLY CHAIN CONTROL PAGE
![3](https://user-images.githubusercontent.com/90173123/218174595-425dbce3-bdbf-4613-8aca-8ec56f3aeca9.PNG)
![4](https://user-images.githubusercontent.com/90173123/218174619-6c8d1ae2-617c-4391-9357-aa18a8a265a1.PNG)
ORDER TRACKING PAGE
![5](https://user-images.githubusercontent.com/90173123/218174716-7e321300-9e61-4e4b-a234-5c3a36f716a3.PNG)
![6](https://user-images.githubusercontent.com/90173123/218174734-fd167305-3aaa-417a-9753-4c517c54cf49.PNG)
